package com.smscontrol.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return
        val bySender = LinkedHashMap<String, StringBuilder>()
        for (m in msgs) {
            bySender.getOrPut(m.originatingAddress ?: "") { StringBuilder() }
                .append(m.messageBody ?: "")
        }
        for ((sender, body) in bySender) Core.handleIncoming(context, sender, body.toString())
    }
}
