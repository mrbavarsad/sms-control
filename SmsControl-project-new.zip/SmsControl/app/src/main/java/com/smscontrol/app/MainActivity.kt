package com.smscontrol.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.telephony.SmsManager
import android.text.Editable
import android.text.InputType
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextWatcher
import android.text.style.AbsoluteSizeSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.min

class MainActivity : Activity() {

    private val BG_TOP = Color.parseColor("#323840")
    private val BG_BOTTOM = Color.parseColor("#22262C")
    private val CARD = Color.parseColor("#343941")
    private val CARD_STROKE = Color.parseColor("#454B55")
    private val GRAY = Color.parseColor("#A9AEB5")
    private val GRAY_SIDE = Color.parseColor("#62676F")
    private val GREEN = Color.parseColor("#A8D8B0")       // soft green = ON
    private val GREEN_SIDE = Color.parseColor("#5F9A6B")
    private val GREEN_RING = Color.parseColor("#D6F1DB")
    private val TEXT_DARK = Color.parseColor("#1F2328")
    private val TEXT_SOFT = Color.parseColor("#3E444C")
    private val MUTED = Color.parseColor("#9AA0A6")

    private val keys = HashMap<Int, TextView>()
    private lateinit var phone: EditText
    private lateinit var tempBtn: TextView
    private lateinit var tempOut: TextView
    private lateinit var eventView: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            checkTimeouts()
            handler.postDelayed(this, 1000)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private val prefs get() = Core.prefs(this)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG_TOP
        window.navigationBarColor = BG_BOTTOM
        buildUi()
        if (!hasSmsPerm()) requestSmsPerm()
    }

    override fun onResume() {
        super.onResume()
        Core.listener = { refresh() }
        refresh()
        handler.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        Core.listener = null
        handler.removeCallbacks(ticker)
    }

    // ---------------------------------------------------------------- UI

    private fun lp(w: Int, h: Int, top: Int = 0, bottom: Int = 0) =
        LinearLayout.LayoutParams(w, h).apply {
            topMargin = dp(top)
            bottomMargin = dp(bottom)
        }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(12), dp(12), dp(12), dp(12))
        background = GradientDrawable().apply {
            cornerRadius = dp(20).toFloat()
            setColor(CARD)
            setStroke(dp(1), CARD_STROKE)
        }
    }

    private fun buildUi() {
        val MATCH = LinearLayout.LayoutParams.MATCH_PARENT
        val WRAP = LinearLayout.LayoutParams.WRAP_CONTENT

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(28), dp(16), dp(24))
        }

        root.addView(TextView(this).apply {
            text = "کنترل پیامکی"
            textSize = 26f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }, lp(MATCH, WRAP))
        root.addView(TextView(this).apply {
            text = "ارسال فرمان به دستگاه GSM"
            textSize = 13f
            setTextColor(MUTED)
            gravity = Gravity.CENTER
        }, lp(MATCH, WRAP, 2, 18))

        // ---- phone number card
        val phoneCard = card()
        phoneCard.addView(TextView(this).apply {
            text = "شماره موبایل"
            setTextColor(Color.parseColor("#D0D4DA"))
            textSize = 15f
            setPadding(dp(4), 0, dp(4), dp(8))
        })
        phone = EditText(this).apply {
            hint = "مثال: 09123456789"
            setHintTextColor(Color.parseColor("#7C838D"))
            setTextColor(Color.WHITE)
            textSize = 20f
            inputType = InputType.TYPE_CLASS_PHONE
            setSingleLine(true)
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(Color.parseColor("#2A2E35"))
                setStroke(dp(1), Color.parseColor("#4A505A"))
            }
            setText(prefs.getString("phone", ""))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    prefs.edit().putString("phone", s.toString().trim()).apply()
                }
            })
        }
        phoneCard.addView(phone, lp(MATCH, WRAP))
        root.addView(phoneCard, lp(MATCH, WRAP, 0, 14))

        // ---- keys card
        val keysCard = card()
        for (row in 0 until 4) {
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (n in intArrayOf(row * 2 + 1, row * 2 + 2)) {
                val k = makeKey { pressKey(n) }
                keys[n] = k
                line.addView(k, LinearLayout.LayoutParams(0, dp(88), 1f).apply {
                    setMargins(dp(6), dp(6), dp(6), dp(6))
                })
            }
            keysCard.addView(line, lp(MATCH, WRAP))
        }
        root.addView(keysCard, lp(MATCH, WRAP, 0, 8))

        eventView = TextView(this).apply {
            textSize = 13f
            setTextColor(MUTED)
            gravity = Gravity.CENTER
        }
        root.addView(eventView, lp(MATCH, WRAP, 4, 10))

        // ---- temperature card
        val tempCard = card()
        val tempRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        tempBtn = makeKey { pressTemp() }
        tempRow.addView(tempBtn, LinearLayout.LayoutParams(0, dp(88), 1f).apply {
            setMargins(dp(6), dp(6), dp(6), dp(6))
        })
        tempOut = TextView(this).apply {
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
        }
        tempRow.addView(tempOut, LinearLayout.LayoutParams(0, dp(88), 1.2f))
        tempCard.addView(tempRow, lp(MATCH, WRAP))
        root.addView(tempCard, lp(MATCH, WRAP))

        setContentView(ScrollView(this).apply {
            isFillViewport = true
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(BG_TOP, BG_BOTTOM)
            )
            addView(root)
        })
    }

    private fun makeKey(onClick: () -> Unit): TextView =
        TextView(this).apply {
            textSize = 24f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(TEXT_DARK)
            isClickable = true
            setOnClickListener {
                hideKeyboard()
                onClick()
            }
            setOnTouchListener { v, ev ->
                when (ev.action) {
                    MotionEvent.ACTION_DOWN -> {
                        stylePad(v, true)
                        v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> stylePad(v, false)
                }
                false
            }
            styleKey(this, false)
        }

    private fun hideKeyboard() {
        phone.clearFocus()
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(phone.windowToken, 0)
    }

    private fun twoLine(
        big: String, small: String, bigSp: Int, smallSp: Int, bigColor: Int, smallColor: Int
    ): CharSequence {
        val sb = SpannableStringBuilder()
        sb.append(big)
        sb.setSpan(AbsoluteSizeSpan(bigSp, true), 0, big.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        sb.setSpan(StyleSpan(Typeface.BOLD), 0, big.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        sb.setSpan(ForegroundColorSpan(bigColor), 0, big.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        if (small.isNotEmpty()) {
            val start = sb.length + 1
            sb.append("\n").append(small)
            sb.setSpan(AbsoluteSizeSpan(smallSp, true), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            sb.setSpan(ForegroundColorSpan(smallColor), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        return sb
    }

    private fun stylePad(v: View, pressed: Boolean) {
        if (pressed) v.setPadding(0, dp(6), 0, dp(2)) else v.setPadding(0, 0, 0, dp(8))
    }

    private fun styleKey(v: View, lit: Boolean) {
        val face = if (lit) GREEN else GRAY
        val side = if (lit) GREEN_SIDE else GRAY_SIDE
        val ring = if (lit) GREEN_RING else null
        v.background = StateListDrawable().apply {
            addState(
                intArrayOf(android.R.attr.state_pressed),
                keyDrawable(shade(face, 0.94f), shade(face, 0.88f), side, ring, true)
            )
            addState(
                intArrayOf(),
                keyDrawable(shade(face, 1.10f), face, side, ring, false)
            )
        }
        stylePad(v, false)
    }

    private fun faceRect(top: Int, bottom: Int, ring: Int?) =
        GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, bottom)).apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(18).toFloat()
            if (ring != null) setStroke(dp(2), ring)
        }

    private fun sideRect(color: Int) = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(18).toFloat()
        setColor(color)
    }

    /** 3-D key: a darker "side" slab with the face on top; pressed = face sinks down. */
    private fun keyDrawable(top: Int, bottom: Int, side: Int, ring: Int?, pressed: Boolean): Drawable {
        val ld = LayerDrawable(arrayOf<Drawable>(sideRect(side), faceRect(top, bottom, ring)))
        if (pressed) ld.setLayerInset(1, 0, dp(6), 0, dp(2)) else ld.setLayerInset(1, 0, 0, 0, dp(8))
        return ld
    }

    private fun shade(c: Int, f: Float) = Color.rgb(
        min(255, (Color.red(c) * f).toInt()),
        min(255, (Color.green(c) * f).toInt()),
        min(255, (Color.blue(c) * f).toInt())
    )

    private fun refresh() {
        val p = prefs
        for (n in 1..8) {
            val k = keys[n] ?: continue
            val ch = (n + 1) / 2
            val pending = p.getInt("pend_$ch", 0) == n
            val caption = if (pending) "در انتظار پاسخ…"
            else "خروجی $ch ${if (n % 2 == 1) "روشن" else "خاموش"}"
            k.text = twoLine("$n", caption, 28, 12, TEXT_DARK, TEXT_SOFT)
            styleKey(k, p.getBoolean("on_$n", false))
        }

        val tempPending = p.getLong("temp_pending", 0L) > 0L
        tempBtn.text = twoLine("دما", if (tempPending) "در انتظار پاسخ…" else "", 26, 12, TEXT_DARK, TEXT_SOFT)

        val raw = p.getString("temp_result", "") ?: ""
        if (raw.isEmpty()) {
            tempOut.text = ""
        } else {
            val num = Regex("[+-]?\\d+(?:\\.\\d+)?").find(Core.normalizeDigits(raw))?.value
            val big = if (num != null) "${num.removePrefix("+")} °C" else raw
            val t = p.getLong("temp_time", 0L)
            val small = if (t > 0L) "ساعت ${Core.clock(t)}" else ""
            tempOut.text = twoLine(big, small, 30, 13, Color.WHITE, MUTED)
        }

        val last = p.getString("last_event", null)
        eventView.text = if (last != null) "آخرین وضعیت: $last" else "هنوز پاسخی از دستگاه دریافت نشده"
    }

    // ----------------------------------------------------------- actions

    private fun pressKey(n: Int) {
        val num = phone.text.toString().trim()
        if (num.isEmpty()) { toast("ابتدا شماره موبایل را وارد کنید"); return }
        if (!hasSmsPerm()) { requestSmsPerm(); toast("اجازه پیامک لازم است"); return }
        if (sendSms(num, Core.codeFor(n))) {
            val ch = (n + 1) / 2
            prefs.edit().putInt("pend_$ch", n).putLong("pendt_$ch", System.currentTimeMillis()).apply()
            refresh()
        }
    }

    private fun pressTemp() {
        val num = phone.text.toString().trim()
        if (num.isEmpty()) { toast("ابتدا شماره موبایل را وارد کنید"); return }
        if (!hasSmsPerm()) { requestSmsPerm(); toast("اجازه پیامک لازم است"); return }
        if (sendSms(num, "temp")) {
            prefs.edit().putLong("temp_pending", System.currentTimeMillis()).apply()
            refresh()
        }
    }

    private fun checkTimeouts() {
        val p = prefs
        val now = System.currentTimeMillis()
        var changed = false
        val ed = p.edit()
        for (ch in 1..4) {
            val t = p.getLong("pendt_$ch", 0L)
            if (t > 0L && now - t > Core.TIMEOUT_MS) {
                ed.remove("pend_$ch").remove("pendt_$ch")
                toast("پاسخی برای خروجی $ch دریافت نشد")
                changed = true
            }
        }
        val tt = p.getLong("temp_pending", 0L)
        if (tt > 0L && now - tt > Core.TIMEOUT_MS) {
            ed.remove("temp_pending")
            toast("پاسخ دما دریافت نشد")
            changed = true
        }
        ed.apply()
        if (changed) refresh()
    }

    private fun sendSms(to: String, text: String): Boolean = try {
        val sm = getSystemService(SmsManager::class.java)
        sm.sendTextMessage(to, null, text, null, null)
        true
    } catch (e: Exception) {
        toast("ارسال پیامک ناموفق بود")
        false
    }

    // -------------------------------------------------------- permissions

    private fun hasSmsPerm(): Boolean =
        checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED

    private fun requestSmsPerm() {
        requestPermissions(arrayOf(Manifest.permission.SEND_SMS, Manifest.permission.RECEIVE_SMS), 1)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
