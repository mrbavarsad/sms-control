package com.smscontrol.app

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Core {
    const val PREFS = "smscontrol"
    const val TIMEOUT_MS = 60_000L

    /** Called (on main thread) when state changed because of an incoming SMS. */
    var listener: (() -> Unit)? = null

    fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun clock(t: Long): String = SimpleDateFormat("HH:mm", Locale.US).format(Date(t))

    fun normalizeDigits(s: String): String {
        val sb = StringBuilder()
        for (ch in s) {
            sb.append(
                when (ch) {
                    in '\u06F0'..'\u06F9' -> '0' + (ch - '\u06F0')
                    in '\u0660'..'\u0669' -> '0' + (ch - '\u0660')
                    else -> ch
                }
            )
        }
        return sb.toString()
    }

    /** Last 10 digits, so 0912..., +98912... and 0098912... all compare equal. */
    fun digitsTail(s: String): String {
        val d = normalizeDigits(s).filter { it.isDigit() }
        return if (d.length > 10) d.takeLast(10) else d
    }

    /** Buttons 1..8 -> 11,10,21,20,31,30,41,40 */
    fun codeFor(button: Int): String =
        "${(button + 1) / 2}${if (button % 2 == 1) 1 else 0}"

    fun handleIncoming(c: Context, sender: String, body: String) {
        val p = prefs(c)
        val saved = digitsTail(p.getString("phone", "") ?: "")
        if (saved.isEmpty() || digitsTail(sender) != saved) return

        val now = System.currentTimeMillis()
        val text = normalizeDigits(body).lowercase()
        val ed = p.edit()
        var matched = false

        for (line in text.split('\n')) {
            val m = Regex("[1-4]").find(line) ?: continue
            val ch = m.value.toInt()
            val off = line.contains("خاموش") || Regex("\\boff\\b").containsMatchIn(line)
            val on = !off && (line.contains("روشن") || Regex("\\bon\\b").containsMatchIn(line))
            if (!off && !on) continue
            // on  -> odd button lit, even off ; off -> even button lit, odd off
            ed.putBoolean("on_${ch * 2 - 1}", on)
            ed.putBoolean("on_${ch * 2}", !on)
            ed.remove("pend_$ch").remove("pendt_$ch")
            ed.putString("last_event", "خروجی $ch ${if (on) "روشن" else "خاموش"}  •  ${clock(now)}")
            matched = true
        }

        if (!matched && p.getLong("temp_pending", 0L) > 0L) {
            ed.putString("temp_result", body.trim()).putLong("temp_time", now).remove("temp_pending")
        }
        ed.apply()
        listener?.invoke()
    }
}
